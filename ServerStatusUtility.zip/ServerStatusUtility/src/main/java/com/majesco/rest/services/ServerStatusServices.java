package com.majesco.rest.services;

import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.majesco.utility.Server;
import com.majesco.utility.ServerConfig;
import com.majesco.utility.ServerUtil;

@Path("/envservice")
public class ServerStatusServices {
	
	@Path("/getdetails")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public ServerConfig getServerDetails(){
		return ServerUtil.getServerUtil().getServerConfig();
	}
	
	@Path("/checkStatus/{index}/{serverIp}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Server checkServerStatus(@PathParam("index") int index, @PathParam("serverIp") String serverIp){
		URL url;
		Server server = new Server();
		server.setServerIP(serverIp);
		server.setTempIndex(index);
		try {
			url = new URL("http://" + serverIp);
			URLConnection urlCon = url.openConnection();
			urlCon.connect();
			server.setServerStatus("Running");
			server.setAlertProperty("alert alert-success");
			server.setStartBtnVisibility("disabled");
			server.setStopBtnVisibility("");
			return server;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			server.setServerStatus("Down");
			server.setAlertProperty("alert alert-danger");
			server.setStartBtnVisibility("");
			server.setStopBtnVisibility("disabled");
			return server;
		}
	}
}

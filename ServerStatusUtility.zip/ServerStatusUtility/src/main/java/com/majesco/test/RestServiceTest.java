package com.majesco.test;

public class RestServiceTest {
	public static void main(String[] args) {
		
	}
}

package com.majesco.test;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import com.majesco.utility.Server;
import com.majesco.utility.ServerConfig;
import com.majesco.utility.ServerUtil;

public class ServerJAXBTest {
	public static void main(String[] args) {
		ServerConfig serversList = new ServerConfig();
		List<Server> serverList = new ArrayList<Server>();
		Server server1 = new Server();
		server1.setServerName("IN-PN1X07P15004.majesco.com");
		server1.setServerIP("172.17.73.26");
		server1.setServerStatus("Down");
		server1.setServerPort("9090");
		serverList.add(server1);
		
		Server server2 = new Server();
		server2.setServerName("IN-PN1X07P15005.majesco.com");
		server2.setServerIP("172.17.73.31");
		server2.setServerStatus("Running");
		server2.setServerPort("9090");
		serverList.add(server2);
		
		serversList.server = serverList;
		
		try {
			Marshaller marshaller = JAXBContext.newInstance(ServerConfig.class).createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			marshaller.marshal(serversList, System.out);
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		/*ServerUtil serverUtil = ServerUtil.getServerUtil();*/
		System.out.println("Completed");
	}
}

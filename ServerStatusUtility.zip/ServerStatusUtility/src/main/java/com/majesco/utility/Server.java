package com.majesco.utility;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;


public class Server {
	String serverName;
	String serverIP;
	String serverPort;
	String serverStatus = "";
	String alertProperty = "";
	int tempIndex;
	String startBtnVisibility;
	String stopBtnVisibility;
	
	@XmlElement
	public String getServerName() {
		return serverName;
	}
	public void setServerName(String serverName) {
		this.serverName = serverName;
	}
	
	@XmlElement
	public String getServerIP() {
		return serverIP;
	}
	public void setServerIP(String serverIP) {
		this.serverIP = serverIP;
	}
	
	@XmlElement
	public String getServerPort() {
		return serverPort;
	}
	public void setServerPort(String serverPort) {
		this.serverPort = serverPort;
	}
	
	@XmlElement
	public String getServerStatus() {
		return serverStatus;
	}
	public void setServerStatus(String serverStatus) {
		this.serverStatus = serverStatus;
	}
	
	public String getAlertProperty() {
		return alertProperty;
	}
	public void setAlertProperty(String alertProperty) {
		this.alertProperty = alertProperty;
	}
	
	public int getTempIndex() {
		return tempIndex;
	}
	public void setTempIndex(int tempIndex) {
		this.tempIndex = tempIndex;
	}
	public String getStartBtnVisibility() {
		return startBtnVisibility;
	}
	public void setStartBtnVisibility(String startBtnVisibility) {
		this.startBtnVisibility = startBtnVisibility;
	}
	public String getStopBtnVisibility() {
		return stopBtnVisibility;
	}
	public void setStopBtnVisibility(String stopBtnVisibility) {
		this.stopBtnVisibility = stopBtnVisibility;
	}
	
	
}

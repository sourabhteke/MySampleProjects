package com.majesco.utility;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

public class ServerUtil {
	
	private static ServerUtil instance;
	private ServerConfig serverConfig;
	
	private ServerUtil(){
		loadServerDetails();
	}

	public static ServerUtil getServerUtil(){
		if(instance == null){
			synchronized(ServerUtil.class) {
				if(instance == null){
					instance = new ServerUtil();
				}
			}
		}
		return instance;
	}
	
	private void loadServerDetails() {
		// TODO Auto-generated method stub
		try {
			BufferedReader reader = new BufferedReader(new FileReader("D:\\Eclipse_Workspaces\\Test\\ServerStatusUtility\\src\\main\\resources\\server_config.xml"));
			Unmarshaller unmarshaller = JAXBContext.newInstance(ServerConfig.class).createUnmarshaller();
			serverConfig = (ServerConfig) unmarshaller.unmarshal(reader);
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void checkCurrentStatus() {
		// TODO Auto-generated method stub
		for(Server curServer:serverConfig.server){
			URL url;
			try {
				url = new URL("http://" + curServer.serverIP);
				URLConnection urlCon = url.openConnection();
				urlCon.connect();
				curServer.setServerStatus("Running");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				curServer.setServerStatus("Down");
				e.printStackTrace();
			}
		}
	}
	
	public ServerConfig getServerConfig(){
		return instance.serverConfig;
	}
}
